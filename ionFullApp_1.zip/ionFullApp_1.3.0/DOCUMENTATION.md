You can find ionFullApp documentation here: https://docs.google.com/document/d/1Oh0EfqUCzzPoUdHiSFcxykTy65afY7g4mHz3wXtBabo/edit?usp=sharing
